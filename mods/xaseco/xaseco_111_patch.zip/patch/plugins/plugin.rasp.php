<?php
/* vim: set noexpandtab tabstop=2 softtabstop=2 shiftwidth=2: */

/**
 * RASP plugin.
 * Provides rank & personal best handling, and related chat commands.
 * Updated by Xymph
 *
 * Dependencies: requires plugin.rasp_karma.php
 */

Aseco::registerEvent('onStartup', 'event_onstartup');
Aseco::registerEvent('onSync', 'event_onsync');
Aseco::registerEvent('onNewChallenge2', 'event_newtrack');  // use 2nd event for logical ordering of rank/karma messages
Aseco::registerEvent('onEndRace', 'event_endrace');
Aseco::registerEvent('onPlayerFinish', 'event_finish');
Aseco::registerEvent('onPlayerConnect', 'event_playerjoin');

if (!INHIBIT_RECCMDS) {
	Aseco::addChatCommand('pb', 'Shows your personal best on current track');
}
Aseco::addChatCommand('rank', 'Shows your current server rank');
Aseco::addChatCommand('top10', 'Displays top 10 best ranked players');
Aseco::addChatCommand('top100', 'Displays top 100 best ranked players');
Aseco::addChatCommand('topwins', 'Displays top 100 victorious players');
Aseco::addChatCommand('active', 'Displays top 100 most active players');

class Rasp {
	var $aseco;
	var $features;
	var $ranks;
	var $settings;
	var $challenges;
	var $responses;
	var $maxrec;
	var $playerlist;

	function start($aseco_ext, $config_file) {
		global $maxrecs;

		$this->aseco = $aseco_ext;
		$this->aseco->console_text('*-*-*-*-*-* RASP is running! *-*-*-*-*-*');
		$this->aseco->console_text('|...Loading Settings');
		if (!$this->settings = $this->xmlparse($config_file)) {
			trigger_error('{RASP_ERROR} Could not read/parse config file ' . $config_file . ' !', E_USER_ERROR);
		} else {
			$this->aseco->console_text('|...Loaded!');
			$this->aseco->console_text('|...Checking database structure');
			if (!$this->checkTables()) {
				trigger_error('{RASP_ERROR} Table structure incorrect, use the rasp.sql file to correct this.', E_USER_ERROR);
			}
			$this->aseco->console_text('|...Structure OK!');
			$this->aseco->server->records->setLimit($maxrecs);

			//$this->resetRanks();
		}
	}  // start

	function xmlparse($config_file) {

		if ($settings = $this->aseco->xml_parser->parseXml($config_file)) {
			$this->messages = $settings['RASP']['MESSAGES'][0];
			return $settings;
		} else {
			return false;
		}
	}  // xmlparse

	function checkTables() {
		global $ldb_settings;

		$query = 'CREATE TABLE IF NOT EXISTS `'.$ldb_settings['mysql']['prefix'].'rs_times` (
		           `Id` mediumint(9) NOT NULL auto_increment,
		           `challengeID` mediumint(9) NOT NULL default 0,
		           `playerID` mediumint(9) NOT NULL default 0,
		           `score` mediumint(9) NOT NULL default 0,
		           `date` int(10) unsigned NOT NULL default 0,
		           PRIMARY KEY (`ID`)
		         ) TYPE=MyISAM;';
		mysql_query($query);

		$query = 'CREATE TABLE IF NOT EXISTS `'.$ldb_settings['mysql']['prefix'].'rs_rank` (
		           `playerID` mediumint(9) NOT NULL default 0,
		           `avg` float NOT NULL default 0,
		           KEY `playerID` (`playerID`)
		         ) TYPE=MyISAM;';
		mysql_query($query);

		$query = 'CREATE TABLE IF NOT EXISTS `'.$ldb_settings['mysql']['prefix'].'rs_karma` (
		           `Id` int(11) NOT NULL auto_increment,
		           `Score` smallint(6) NOT NULL default 0,
		           `PlayerId` mediumint(9) NOT NULL default 0,
		           `ChallengeId` mediumint(9) NOT NULL default 0,
		           PRIMARY KEY (`Id`),
		           UNIQUE KEY `PlayerId` (`PlayerId`,`ChallengeId`),
		           KEY `ChallengeId` (`ChallengeId`)
		         ) TYPE=MyISAM;';
		mysql_query($query);

		$tables = array();
		$res = mysql_query('SHOW TABLES');
		while ($row = mysql_fetch_row($res))
			$tables[] = $row[0];
		mysql_free_result($res);

		$check = array();
		$check[1] = in_array($ldb_settings['mysql']['prefix'].'rs_rank', $tables);
		$check[2] = in_array($ldb_settings['mysql']['prefix'].'rs_times', $tables);
		$check[3] = in_array($ldb_settings['mysql']['prefix'].'rs_karma', $tables);

		// rename rs_times column 'trackID' (v0.7) to 'challengeID' (v0.8) if not yet done
		$fields = array();
		$res = mysql_query('SHOW COLUMNS FROM '.$ldb_settings['mysql']['prefix'].'rs_times');
		while ($row = mysql_fetch_row($res))
			$fields[] = $row[0];
		mysql_free_result($res);

		if (in_array('trackID', $fields)) {
			mysql_query('ALTER TABLE '.$ldb_settings['mysql']['prefix'].'rs_times CHANGE trackID challengeID mediumint(9) NOT NULL default 0');
		}
		// add 'checkpoints' column if not yet done
		if (!in_array('checkpoints', $fields)) {
			mysql_query('ALTER TABLE '.$ldb_settings['mysql']['prefix'].'rs_times ADD checkpoints text NOT NULL');
		}

		// add index to rs_times table
		$res = mysql_query('SHOW CREATE TABLE rs_times');
		$row = mysql_fetch_row($res);
		if (stripos($row[1], 'rs_times_player_track') == 0) {
			mysql_query('CREATE INDEX rs_times_player_track ON '.$ldb_settings['mysql']['prefix'].'rs_times (playerID, challengeID)');
		}
		mysql_free_result($res);

		return ($check[1] && $check[2] && $check[3]);
	}  // checkTables

	function getChallenges() {
		global $ldb_settings;

		// get new list of all tracks
		$this->aseco->client->resetError();
		$newlist = array();
		$done = false;
		$size = 300;
		$i = 0;
		while (!$done) {
			$this->aseco->client->query('GetChallengeList', $size, $i);
			$tracks = $this->aseco->client->getResponse();
			if (!empty($tracks)) {
				if ($this->aseco->client->isError()) {
					// warning if no tracks found
					if (empty($newlist))
						trigger_error('[' . $this->aseco->client->getErrorCode() . '] ' . $this->aseco->client->getErrorMessage() . '  No tracks found!', E_USER_WARNING);
					$done = true;
					break;
				}
				foreach ($tracks as $trow) {
					$trow['Name'] = stripNewlines($trow['Name']);
					$newlist[] = $trow;
				}
				if (count($tracks) < $size) {
					// got less than 300 tracks, might as well leave
					$done = true;
				} else {
					$i += $size;
				}
			} else {
				$done = true;
			}
		}

		foreach ($newlist as $row) {
			$query = 'SELECT * FROM '.$ldb_settings['mysql']['prefix'].'challenges
			          WHERE Uid=' . quotedString($row['UId']);
			$res = mysql_query($query);
			if (mysql_num_rows($res) == 0) {
				$this->aseco->client->query('GetChallengeInfo', $row['FileName']);
				$track = $this->aseco->client->getResponse();
				if ($this->aseco->client->isError()) {
					trigger_error('[' . $this->aseco->client->getErrorCode() . '] ' . $this->aseco->client->getErrorMessage(), E_USER_WARNING);
				} else {
					$row['Author'] = $track['Author'];
				}
				// insert in case it wasn't in the database yet
				$query = 'INSERT INTO '.$ldb_settings['mysql']['prefix'].'challenges (Uid, Name, Author, Environment)
				          VALUES (' . quotedString($row['UId']) . ', ' . quotedString($row['Name']) . ', '
				                    . quotedString($row['Author']) . ', ' . quotedString($row['Environnement']) . ')';
				mysql_query($query);
				if (mysql_affected_rows() != 1) {
					trigger_error('{RASP_ERROR} Could not insert challenge! (' . mysql_error() . ')' . CRLF . 'sql = ' . $query, E_USER_WARNING);
				}
			}
			$tlist[] = $this->aseco->getChallengeId($row['UId']);
			mysql_free_result($res);
		}

		// check for missing challenge list
		if (empty($tlist)) {
			trigger_error('{RASP_ERROR} Cannot obtain challenge list from server and/or database - check configuration files!', E_USER_ERROR);
		}
		$this->challenges = $tlist;
	}  // getChallenges

	// called @ onSync
	function onSync($aseco, $data) {
		global $tmxdir, $tmxtmpdir, $feature_tmxadd;

		$sepchar = substr($aseco->server->trackdir, -1, 1);
		if ($sepchar == '\\') {
			$tmxdir = str_replace('/', $sepchar, $tmxdir);
		}

		if (!file_exists($aseco->server->trackdir . $tmxdir)) {
			if (!mkdir($aseco->server->trackdir . $tmxdir)) {
				$aseco->console_text('{RASP_ERROR} TMX Directory (' . $aseco->server->trackdir . $tmxdir . ') cannot be created');
			}
		}

		if (!is_writeable($aseco->server->trackdir . $tmxdir)) {
			$aseco->console_text('{RASP_ERROR} TMX Directory (' . $aseco->server->trackdir . $tmxdir . ') cannot be written to');
		}

		// check if user /add votes are enabled
		if ($feature_tmxadd) {
			if (!file_exists($aseco->server->trackdir . $tmxtmpdir)) {
				if (!mkdir($aseco->server->trackdir . $tmxtmpdir)) {
					$aseco->console_text('{RASP_ERROR} TMXtmp Directory (' . $aseco->server->trackdir . $tmxtmpdir . ') cannot be created');
					$feature_tmxadd = false;
				}
			}

			if (!is_writeable($aseco->server->trackdir . $tmxtmpdir)) {
				$aseco->console_text('{RASP_ERROR} TMXtmp Directory (' . $aseco->server->trackdir . $tmxtmpdir . ') cannot be written to');
				$feature_tmxadd = false;
			}
		}
	}  // onSync

	function resetRanks() {
		global $maxrecs, $minrank, $ldb_settings;

		$players = array();
		$this->aseco->console_text('|...Calculating ranks');
		$this->getChallenges();
		$tracks = $this->challenges;
		$total = count($tracks);

		// erase old average data
		mysql_query('TRUNCATE TABLE '.$ldb_settings['mysql']['prefix'].'rs_rank');

		// get list of players with at least $minrecs records (possibly unranked)
		$query = 'SELECT PlayerId, COUNT(*) AS cnt
		          FROM '.$ldb_settings['mysql']['prefix'].'records
		          GROUP BY PlayerId
		          HAVING cnt >=' . $minrank;
		$res = mysql_query($query);
		while ($row = mysql_fetch_object($res)) {
			$players[$row->PlayerId] = array(0, 0);  // sum, count
		}
		mysql_free_result($res);

		if (!empty($players)) {
			// get ranked records for all tracks
			$order = ($this->aseco->server->gameinfo->mode == 4 ? 'DESC' : 'ASC');
			foreach ($tracks as $track) {
				$query = 'SELECT PlayerId FROM '.$ldb_settings['mysql']['prefix'].'records
				          WHERE challengeid=' . $track . '
				          ORDER BY score ' . $order . ',date ASC
				          LIMIT ' . $maxrecs;
				$res = mysql_query($query);
				if (mysql_num_rows($res) > 0) {
					$i = 1;
					while ($row = mysql_fetch_object($res)) {
						$pid = $row->PlayerId;
						if (isset($players[$pid])) {
							$players[$pid][0] += $i;
							$players[$pid][1] ++;
						}
						$i++;
					}
				}
				mysql_free_result($res);
			}

			// one-shot insert for queries up to 1 MB (default max_allowed_packet),
			// or about 75K rows at 14 bytes/row (avg)
			$query = 'INSERT INTO '.$ldb_settings['mysql']['prefix'].'rs_rank VALUES ';
			// compute each player's new average score
			foreach ($players as $player => $ranked) {
				// ranked tracks sum + $maxrecs rank for all remaining tracks
				$avg = ($ranked[0] + ($total - $ranked[1]) * $maxrecs) / $total;
				$query .= '(' . $player . ',' . round($avg * 10000) . '),';
			}
			$query = substr($query, 0, strlen($query)-1);  // strip trailing ','
			mysql_query($query);
			if (mysql_affected_rows() < 1) {
				trigger_error('{RASP_ERROR} Could not insert any player averages! (' . mysql_error() . ')', E_USER_WARNING);
			} elseif (mysql_affected_rows() != count($players)) {
				trigger_error('{RASP_ERROR} Could not insert all ' . count($players) . ' player averages! (' . mysql_error() . ')', E_USER_WARNING);
				// increase MySQL's max_allowed_packet setting
			}
		}
		$this->aseco->console_text('|...Done!');
	}  // resetRanks

	// called @ onPlayerConnect
	function onPlayerjoin($aseco, $player) {
		global $feature_ranks, $feature_stats, $always_show_pb;

		if ($feature_ranks)
			$this->showRank($player->login);
		if ($feature_stats)
			$this->showPb($player, $aseco->server->challenge->id, $always_show_pb);
	}  // onPlayerjoin

	function showPb($player, $track, $always_show) {
		global $maxrecs, $maxavg, $ldb_settings;

		$found = false;
		// find ranked record
		for ($i = 0; $i < $maxrecs; $i++) {
			if (($rec = $this->aseco->server->records->getRecord($i)) !== false) {
				if ($rec->player->login == $player->login) {
					$ret['time'] = $rec->score;
					$ret['rank'] = $i + 1;
					$found = true;
					break;
				}
			} else {
				break;
			}
		}

		// check whether to show PB (e.g. for /pb)
		if (!$always_show) {
			// check for ranked record that's already shown at track start,
			// or for player's records panel showing it
			if (($found && $this->aseco->settings['show_recs_before'] == 2) ||
			    $player->panels['records'] != '')
				return;
		}

		$pid = $this->aseco->getPlayerId($player->login);
		if (!$found) {
			// find unranked time/score
			$order = ($this->aseco->server->gameinfo->mode == 4 ? 'DESC' : 'ASC');
			$query2 = 'SELECT score FROM '.$ldb_settings['mysql']['prefix'].'rs_times
			           WHERE playerID=' . $pid . ' && challengeID=' . $track . '
			           ORDER BY score ' . $order . ' LIMIT 1';
			$res2 = mysql_query($query2);
			if (mysql_num_rows($res2) > 0) {
				$row = mysql_fetch_object($res2);
				$ret['time'] = $row->score;
				$ret['rank'] = '$nUNRANKED$m';
				$found = true;
			}
			mysql_free_result($res2);
		}

		// compute average time of last $maxavg times
		$query = 'SELECT score FROM '.$ldb_settings['mysql']['prefix'].'rs_times
		          WHERE playerID=' . $pid . ' && challengeID=' . $track . '
		          ORDER BY date DESC LIMIT ' . $maxavg;
		$res = mysql_query($query);
		$size = mysql_num_rows($res);
		if ($size > 0) {
			$total = 0;
			while ($row = mysql_fetch_object($res)) {
				$total += $row->score;
			}
			$avg = floor($total / $size);
			if ($this->aseco->server->gameinfo->mode != 4)
				$avg = formatTime($avg);
		} else {
			$avg = 'No Average';
		}
		mysql_free_result($res);

		if ($found) {
			$message = formatText($this->messages['PB'][0],
			                      ($this->aseco->server->gameinfo->mode == 4 ?
			                       $ret['time'] : formatTime($ret['time'])),
			                      $ret['rank'], $avg);
			$message = $this->aseco->formatColors($message);
			$this->aseco->client->query('ChatSendServerMessageToLogin', $message, $player->login);
		} else {
			$message = $this->messages['PB_NONE'][0];
			$message = $this->aseco->formatColors($message);
			$this->aseco->client->query('ChatSendServerMessageToLogin', $message, $player->login);
		}
	}  // showPb

	function getPb($login, $track) {
		global $maxrecs, $ldb_settings;

		$found = false;
		// find ranked record
		for ($i = 0; $i < $maxrecs; $i++) {
			if (($rec = $this->aseco->server->records->getRecord($i)) !== false) {
				if ($rec->player->login == $login) {
					$ret['time'] = $rec->score;
					$ret['rank'] = $i + 1;
					$found = true;
					break;
				}
			} else {
				break;
			}
		}

		if (!$found) {
			$pid = $this->aseco->getPlayerId($login);
			// find unranked time/score
			$order = ($this->aseco->server->gameinfo->mode == 4 ? 'DESC' : 'ASC');
			$query2 = 'SELECT score FROM '.$ldb_settings['mysql']['prefix'].'rs_times
			           WHERE playerID=' . $pid . ' && challengeID=' . $track . '
			           ORDER BY score ' . $order . ' LIMIT 1';
			$res2 = mysql_query($query2);
			if (mysql_num_rows($res2) > 0) {
				$row = mysql_fetch_object($res2);
				$ret['time'] = $row->score;
				$ret['rank'] = '$nUNRANKED$m';
			} else {
				$ret['time'] = 0;
				$ret['rank'] = '$nNONE$m';
			}
			mysql_free_result($res2);
		}

		return $ret;
	}  // getPb

	function showRank($login) {
		global $minrank, $ldb_settings;

		$pid = $this->aseco->getPlayerId($login);
		$query = 'SELECT avg FROM '.$ldb_settings['mysql']['prefix'].'rs_rank
		          WHERE playerID=' . $pid;
		$res = mysql_query($query);
		if (mysql_num_rows($res) > 0) {
			$row = mysql_fetch_array($res);
			$query2 = 'SELECT playerid FROM '.$ldb_settings['mysql']['prefix'].'rs_rank ORDER BY avg ASC';
			$res2 = mysql_query($query2);
			$rank = 1;
			while ($row2 = mysql_fetch_array($res2)) {
				if ($row2['playerid'] == $pid) break;
				$rank++;
			}
			$message = formatText($this->messages['RANK'][0],
			                      $rank, mysql_num_rows($res2),
			                      sprintf("%4.1F", $row['avg'] / 10000));
			$message = $this->aseco->formatColors($message);
			$this->aseco->client->query('ChatSendServerMessageToLogin', $message, $login);
			mysql_free_result($res2);
		} else {
			$message = formatText($this->messages['RANK_NONE'][0], $minrank);
			$message = $this->aseco->formatColors($message);
			$this->aseco->client->query('ChatSendServerMessageToLogin', $message, $login);
		}
		mysql_free_result($res);
	}  // showRank

	function getRank($login) {
		global $ldb_settings;

		$pid = $this->aseco->getPlayerId($login);
		$query = 'SELECT avg FROM '.$ldb_settings['mysql']['prefix'].'rs_rank
		          WHERE playerID=' . $pid;
		$res = mysql_query($query);
		if (mysql_num_rows($res) > 0) {
			$row = mysql_fetch_array($res);
			$query2 = 'SELECT playerid FROM '.$ldb_settings['mysql']['prefix'].'rs_rank ORDER BY avg ASC';
			$res2 = mysql_query($query2);
			$rank = 1;
			while ($row2 = mysql_fetch_array($res2)) {
				if ($row2['playerid'] == $pid) break;
				$rank++;
			}
			$message = formatText('{1}/{2} Avg: {3}',
			                      $rank, mysql_num_rows($res2),
			                      sprintf("%4.1F", $row['avg'] / 10000));
			mysql_free_result($res2);
		} else {
			$message = 'None';
		}
		mysql_free_result($res);
		return $message;
	}  // getRank

	// called @ onPlayerFinish
	function onFinish($aseco, $finish_item) {
		global $feature_stats,
		       $checkpoints;  // from plugin.checkpoints.php

		// check for actual finish & no Laps mode
		if ($feature_stats && $finish_item->score > 0 && $aseco->server->gameinfo->mode != 3) {
			$this->insertTime($finish_item, isset($checkpoints[$finish_item->player->login]) ?
			                  implode(',', $checkpoints[$finish_item->player->login]->curr_cps) : '');
		}
	}  // onFinish

	// called @ onNewChallenge2
	function onNewtrack($aseco, $challenge) {
		global $feature_karma, $feature_stats, $always_show_pb, $karma_show_start, $karma_show_votes;

		if ($feature_stats) {
			foreach ($aseco->server->players->player_list as $pl)
				$this->showPb($pl, $challenge->id, $always_show_pb);
		}
		if ($feature_karma && $karma_show_start &&
		    function_exists('rasp_karma')) {
			// show players' actual votes, or global karma message?
			if ($karma_show_votes) {
				// send individual player messages
				foreach ($aseco->server->players->player_list as $pl)
					rasp_karma($challenge->id, $pl->login);
			} else {
				// send more efficient global message
				rasp_karma($challenge->id, false);
			}
		}
	}  // onNewtrack

	function insertTime($time, $cps) {
		global $ldb_settings;

		$pid = $this->aseco->getPlayerId($time->player->login);
		if ($pid != 0) {
			$query = 'INSERT INTO '.$ldb_settings['mysql']['prefix'].'rs_times (playerID, challengeID, score, date, checkpoints)
			          VALUES (' . $pid . ', ' . $time->challenge->id . ', ' . $time->score . ', '
			                    . quotedString(time()) . ', ' . quotedString($cps) . ')';
			mysql_query($query);
			if (mysql_affected_rows() != 1) {
				trigger_error('{RASP_ERROR} Could not insert time! (' . mysql_error() . ')' . CRLF . 'sql = ' . $query, E_USER_WARNING);
			}
		} else {
			trigger_error('{RASP_ERROR} Could not get Player ID for ' . $time->player->login . ' !', E_USER_WARNING);
		}
	}  // insertTime

	function deleteTime($cid, $pid) {
		global $ldb_settings;

		$query = 'DELETE FROM '.$ldb_settings['mysql']['prefix'].'rs_times WHERE challengeID=' . $cid . ' AND playerID=' . $pid;
		mysql_query($query);
		if (mysql_affected_rows() <= 0) {
			trigger_error('{RASP_ERROR} Could not remove time(s)! (' . mysql_error() . ')' . CRLF . 'sql = ' . $query, E_USER_WARNING);
		}
	}  // deleteTime

	// called @ onEndRace
	function onEndrace($aseco, $data) {
		global $feature_ranks, $tmxplayed;

		if ($feature_ranks) {
			if (!$tmxplayed) {
				$this->resetRanks();
			}
			if ($aseco->server->getGame() != 'TMF' || !$aseco->settings['sb_stats_panels']) {
				foreach ($aseco->server->players->player_list as $pl)
					$this->showRank($pl->login);
			}
		}
	}  // onEndrace

}  // class Rasp

// These functions pass the callback data to the Rasp class...
function event_onsync($aseco, $data) { global $rasp; $rasp->onSync($aseco, $data); }
function event_finish($aseco, $data) { global $rasp; $rasp->onFinish($aseco, $data); }
function event_newtrack($aseco, $data) { global $rasp; $rasp->onNewtrack($aseco, $data); }
function event_endrace($aseco, $data) { global $rasp; $rasp->onEndrace($aseco, $data); }
function event_playerjoin($aseco, $data) { global $rasp; $rasp->onPlayerjoin($aseco, $data); }


// Chat commands...

function chat_pb($aseco, $command) {
	global $rasp, $feature_stats;

	if ($feature_stats) {
		$rasp->showPb($command['author'], $aseco->server->challenge->id, true);
	}
}  // chat_pb

function chat_rank($aseco, $command) {
	global $rasp, $feature_ranks;

	if ($feature_ranks) {
		$rasp->showRank($command['author']->login);
	}
}  // chat_rank

function chat_top10($aseco, $command) {
	global $ldb_settings;

	$player = $command['author'];

	if ($aseco->server->getGame() == 'TMN') {
		$recs = 'Current TOP 10 Players:';
		$top = 10;
		$bgn = '{#black}';  // nickname begin
		$end = '$z';  // ... & end colors
	} elseif ($aseco->server->getGame() == 'TMF') {
		$header = 'Current TOP 10 Players:';
		$recs = array();
		$top = 10;
		$bgn = '{#black}';  // nickname begin
	} else {  // TMS/TMO
		$recs = '{#server}> Current TOP 4 Players:{#highlite}';
		$top = 4;
		$bgn = '{#highlite}';
		$end = '{#highlite}';
	}

	$query = 'SELECT p.NickName, r.avg FROM '.$ldb_settings['mysql']['prefix'].'players p
	          LEFT JOIN '.$ldb_settings['mysql']['prefix'].'rs_rank r ON (p.Id=r.PlayerId)
	          WHERE r.avg!=0 ORDER BY r.avg ASC LIMIT ' . $top;
	$res = mysql_query($query);

	if ($aseco->server->getGame() == 'TMN') {
		$i = 1;
		while ($row = mysql_fetch_object($res)) {
			$nick = $row->NickName;
			if (!$aseco->settings['lists_colornicks'])
				$nick = stripColors($nick);
			$recs .= LF . $i . '.  ' . $bgn . str_pad($nick, 20)
			         . $end . ' - ' . sprintf("%4.1F", $row->avg / 10000);
			$i++;
		}

		// display popup message
		$aseco->client->query('SendDisplayServerMessageToLogin', $player->login, $aseco->formatColors($recs), 'OK', '', 0);

	} elseif ($aseco->server->getGame() == 'TMF') {
		$i = 1;
		while ($row = mysql_fetch_object($res)) {
			$nick = $row->NickName;
			if (!$aseco->settings['lists_colornicks'])
				$nick = stripColors($nick);
			$recs[] = array($i . '.',
			                $bgn . $nick,
			                sprintf("%4.1F", $row->avg / 10000));
			$i++;
		}

		// reserve extra width for $w tags
		$extra = ($aseco->settings['lists_colornicks'] ? 0.2 : 0);
		// display ManiaLink message
		display_manialink($player->login, $header, array('BgRaceScore2', 'LadderRank'), $recs, array(0.7+$extra, 0.1, 0.45+$extra, 0.15), 'OK');

	} else {  // TMS/TMO
		$i = 1;
		while ($row = mysql_fetch_object($res)) {
			$recs .= LF . $i . '.  ' . $bgn . str_pad(stripColors($row->NickName), 15)
			         . $end . ' - ' . sprintf("%4.1F", $row->avg / 10000);
			$i++;
		}

		// show chat message
		$aseco->client->query('ChatSendServerMessageToLogin', $aseco->formatColors($recs), $player->login);
	}
	mysql_free_result($res);
}  // chat_top10

function chat_top100($aseco, $command) {
	global $ldb_settings;

	$player = $command['author'];

	if ($aseco->server->getGame() == 'TMN') {
		$head = 'Current TOP 100 Players:';
		$top = 100;
		$bgn = '{#black}';  // nickname begin
		$end = '$z';  // ... & end colors
	} elseif ($aseco->server->getGame() == 'TMF') {
		$head = 'Current TOP 100 Players:';
		$top = 100;
		$bgn = '{#black}';  // nickname begin
	} else {  // TMS/TMO
		$message = '{#server}> {#error}Command unavailable, use {#highlite}$i/top10 {#error}instead.';
		$aseco->client->query('ChatSendServerMessageToLogin', $aseco->formatColors($message), $player->login);
		return;
	}

	$query = 'SELECT p.NickName, r.avg FROM '.$ldb_settings['mysql']['prefix'].'players p
	          LEFT JOIN '.$ldb_settings['mysql']['prefix'].'rs_rank r ON (p.Id=r.PlayerId)
	          WHERE r.avg!=0 ORDER BY r.avg ASC LIMIT ' . $top;
	$res = mysql_query($query);

	if ($aseco->server->getGame() == 'TMN') {
		$recs = '';
		$lines = 0;
		$player->msgs = array();
		$player->msgs[0] = 1;
		$i = 1;
		while ($row = mysql_fetch_object($res)) {
			$nick = $row->NickName;
			if (!$aseco->settings['lists_colornicks'])
				$nick = stripColors($nick);
			$recs .= LF . str_pad($i, 2, '0', STR_PAD_LEFT) . '.  ' . $bgn
			         . str_pad($nick, 20) . $end . ' - '
			         . sprintf("%4.1F", $row->avg / 10000);
			$i++;
			$lines++;
			if ($lines > 9) {
				$player->msgs[] = $aseco->formatColors($head . $recs);
				$lines = 0;
				$recs = '';
			}
		}
		// add if last batch exists
		if ($recs != '')
			$player->msgs[] = $aseco->formatColors($head . $recs);

		// display popup message
		if (count($player->msgs) == 2) {
			$aseco->client->query('SendDisplayServerMessageToLogin', $player->login, $player->msgs[1], 'OK', '', 0);
		} elseif (count($player->msgs) > 2) {
			$aseco->client->query('SendDisplayServerMessageToLogin', $player->login, $player->msgs[1], 'Close', 'Next', 0);
		}  // == 1, no message

	} elseif ($aseco->server->getGame() == 'TMF') {
		$recs = array();
		$lines = 0;
		$player->msgs = array();
		// reserve extra width for $w tags
		$extra = ($aseco->settings['lists_colornicks'] ? 0.2 : 0);
		$player->msgs[0] = array(1, $head, array(0.7+$extra, 0.1, 0.45+$extra, 0.15), array('BgRaceScore2', 'LadderRank'));
		$i = 1;
		while ($row = mysql_fetch_object($res)) {
			$nick = $row->NickName;
			if (!$aseco->settings['lists_colornicks'])
				$nick = stripColors($nick);
			$recs[] = array(str_pad($i, 2, '0', STR_PAD_LEFT) . '.',
			                $bgn . $nick,
			                sprintf("%4.1F", $row->avg / 10000));
			$i++;
			$lines++;
			if ($lines > 14) {
				$player->msgs[] = $recs;
				$lines = 0;
				$recs = array();
			}
		}
		// add if last batch exists
		if (!empty($recs))
			$player->msgs[] = $recs;

		// display ManiaLink message
		display_manialink_multi($player);
	}

	mysql_free_result($res);
}  // chat_top100

function chat_topwins($aseco, $command) {
	global $ldb_settings;

	$player = $command['author'];

	if ($aseco->server->getGame() == 'TMN') {
		$head = 'Current TOP 100 Victors:';
		$top = 100;
		$bgn = '{#black}';  // nickname begin
		$end = '$z';  // ... & end colors
	} elseif ($aseco->server->getGame() == 'TMF') {
		$head = 'Current TOP 100 Victors:';
		$top = 100;
		$bgn = '{#black}';  // nickname begin
	} else {
		$head = '{#server}> Current TOP 4 Victors:{#highlite}';
		$top = 4;
		$bgn = '{#highlite}';
		$end = '{#highlite}';
	}

	$query = 'SELECT NickName, Wins FROM '.$ldb_settings['mysql']['prefix'].'players ORDER BY Wins DESC LIMIT ' . $top;
	$res = mysql_query($query);

	if ($aseco->server->getGame() == 'TMN') {
		$wins = '';
		$i = 1;
		$lines = 0;
		$player->msgs = array();
		$player->msgs[0] = 1;
		while ($row = mysql_fetch_object($res)) {
			$nick = $row->NickName;
			if (!$aseco->settings['lists_colornicks'])
				$nick = stripColors($nick);
			$wins .= LF . str_pad($i, 2, '0', STR_PAD_LEFT) . '.  ' . $bgn
			         . str_pad($nick, 20) . $end . ' - ' . $row->Wins;
			$i++;
			$lines++;
			if ($lines > 9) {
				$player->msgs[] = $aseco->formatColors($head . $wins);
				$lines = 0;
				$wins = '';
			}
		}
		// add if last batch exists
		if ($wins != '')
			$player->msgs[] = $aseco->formatColors($head . $wins);

		// display popup message
		if (count($player->msgs) == 2) {
			$aseco->client->query('SendDisplayServerMessageToLogin', $player->login, $player->msgs[1], 'OK', '', 0);
		} elseif (count($player->msgs) > 2) {
			$aseco->client->query('SendDisplayServerMessageToLogin', $player->login, $player->msgs[1], 'Close', 'Next', 0);
		}  // == 1, no message

	} elseif ($aseco->server->getGame() == 'TMF') {
		$wins = array();
		$i = 1;
		$lines = 0;
		$player->msgs = array();
		// reserve extra width for $w tags
		$extra = ($aseco->settings['lists_colornicks'] ? 0.2 : 0);
		$player->msgs[0] = array(1, $head, array(0.7+$extra, 0.1, 0.45+$extra, 0.15), array('BgRaceScore2', 'LadderRank'));
		while ($row = mysql_fetch_object($res)) {
			$nick = $row->NickName;
			if (!$aseco->settings['lists_colornicks'])
				$nick = stripColors($nick);
			$wins[] = array(str_pad($i, 2, '0', STR_PAD_LEFT) . '.',
			                $bgn . $nick,
			                $row->Wins);
			$i++;
			$lines++;
			if ($lines > 14) {
				$player->msgs[] = $wins;
				$lines = 0;
				$wins = array();
			}
		}
		// add if last batch exists
		if (!empty($wins))
			$player->msgs[] = $wins;

		// display ManiaLink message
		display_manialink_multi($player);

	} else {  // TMS/TMO
		$wins = $head;
		$i = 1;
		while ($row = mysql_fetch_object($res)) {
			$wins .= LF . $i . '.  ' . $bgn . str_pad(stripColors($row->NickName), 15)
			         . $end . ' - ' . $row->Wins;
			$i++;
		}
		// show chat message
		$aseco->client->query('ChatSendServerMessageToLogin', $aseco->formatColors($wins), $player->login);
	}

	mysql_free_result($res);
}  // chat_topwins

function chat_active($aseco, $command) {
	global $ldb_settings;

	$player = $command['author'];

	if ($aseco->server->getGame() == 'TMN') {
		$head = 'TOP 100 Most Active Players:';
		$top = 100;
		$bgn = '{#black}';  // nickname begin
		$end = '$z';  // ... & end colors
	} elseif ($aseco->server->getGame() == 'TMF') {
		$head = 'TOP 100 Most Active Players:';
		$top = 100;
		$bgn = '{#black}';  // nickname begin
	} else {  // TMS/TMO
		$head = '{#server}> Most Active Players:{#highlite}';
		$top = 4;
		$bgn = '{#highlite}';
		$end = '{#highlite}';
	}

	$query = 'SELECT NickName, TimePlayed FROM '.$ldb_settings['mysql']['prefix'].'players ORDER BY TimePlayed DESC LIMIT ' . $top;
	$res = mysql_query($query);

	if ($aseco->server->getGame() == 'TMN') {
		$active = '';
		$i = 1;
		$lines = 0;
		$player->msgs = array();
		$player->msgs[0] = 1;
		while ($row = mysql_fetch_object($res)) {
			$nick = $row->NickName;
			if (!$aseco->settings['lists_colornicks'])
				$nick = stripColors($nick);
			$active .= LF . str_pad($i, 2, '0', STR_PAD_LEFT) . '.  ' . $bgn
			           . str_pad($nick, 20) . $end . ' - '
			           . formatTimeH($row->TimePlayed * 1000, false);
			$i++;
			$lines++;
			if ($lines > 9) {
				$player->msgs[] = $aseco->formatColors($head . $active);
				$lines = 0;
				$active = '';
			}
		}
		// add if last batch exists
		if ($active != '')
			$player->msgs[] = $aseco->formatColors($head . $active);

		// display popup message
		if (count($player->msgs) == 2) {
			$aseco->client->query('SendDisplayServerMessageToLogin', $player->login, $player->msgs[1], 'OK', '', 0);
		} elseif (count($player->msgs) > 2) {
			$aseco->client->query('SendDisplayServerMessageToLogin', $player->login, $player->msgs[1], 'Close', 'Next', 0);
		}  // == 1, no message

	} elseif ($aseco->server->getGame() == 'TMF') {
		$active = array();
		$i = 1;
		$lines = 0;
		$player->msgs = array();
		// reserve extra width for $w tags
		$extra = ($aseco->settings['lists_colornicks'] ? 0.2 : 0);
		$player->msgs[0] = array(1, $head, array(0.8+$extra, 0.1, 0.45+$extra, 0.25), array('BgRaceScore2', 'LadderRank'));
		while ($row = mysql_fetch_object($res)) {
			$nick = $row->NickName;
			if (!$aseco->settings['lists_colornicks'])
				$nick = stripColors($nick);
			$active[] = array(str_pad($i, 2, '0', STR_PAD_LEFT) . '.',
			                  $bgn . $nick,
			                  formatTimeH($row->TimePlayed * 1000, false));
			$i++;
			$lines++;
			if ($lines > 14) {
				$player->msgs[] = $active;
				$lines = 0;
				$active = array();
			}
		}
		// add if last batch exists
		if (!empty($active))
			$player->msgs[] = $active;

		// display ManiaLink message
		display_manialink_multi($player);

	} else {  // TMS/TMO
		$active = $head;
		$i = 1;
		while ($row = mysql_fetch_object($res)) {
			$active .= LF . $i . '.  ' . $bgn . str_pad(stripColors($row->NickName), 15)
			           . $end . ' - ' . formatTimeH($row->TimePlayed * 1000, false);
			$i++;
		}
		// show chat message
		$aseco->client->query('ChatSendServerMessageToLogin', $aseco->formatColors($active), $player->login);
	}

	mysql_free_result($res);
}  // chat_active


// Starts the rasp plugin...

// called @ onStartup
function event_onstartup($aseco) {
	global $rasp, $prune_records_times, $ldb_settings;

	$rasp_config = 'rasp.xml';

	$aseco->console_text('[RASP] Cleaning up unused data');
	$sql = 'DELETE FROM '.$ldb_settings['mysql']['prefix'].'challenges WHERE uid=\'\'';
	mysql_query($sql);
	$sql = 'DELETE FROM '.$ldb_settings['mysql']['prefix'].'players WHERE login=\'\'';
	mysql_query($sql);
	$sql = 'DELETE FROM '.$ldb_settings['mysql']['prefix'].'records WHERE NOT EXISTS (SELECT id FROM '.$ldb_settings['mysql']['prefix'].'players p WHERE p.id=records.PlayerId)';
	mysql_query($sql);
	$sql = 'DELETE FROM '.$ldb_settings['mysql']['prefix'].'records WHERE NOT EXISTS (SELECT id FROM '.$ldb_settings['mysql']['prefix'].'challenges c WHERE c.id=records.ChallengeId)';
	mysql_query($sql);
	$sql = 'DELETE FROM '.$ldb_settings['mysql']['prefix'].'rs_times WHERE NOT EXISTS (SELECT id FROM '.$ldb_settings['mysql']['prefix'].'players p WHERE p.id=rs_times.playerID)';
	mysql_query($sql);
	$sql = 'DELETE FROM '.$ldb_settings['mysql']['prefix'].'rs_times WHERE NOT EXISTS (SELECT id FROM '.$ldb_settings['mysql']['prefix'].'challenges c WHERE c.id=rs_times.challengeID)';
	mysql_query($sql);

	$rasp = new Rasp();
	$rasp->start($aseco, $rasp_config);

	// prune records and rs_times entries for deleted tracks
	if ($prune_records_times) {
		$aseco->console_text('[RASP] Pruning records/rs_times for deleted tracks');
		$rasp->getChallenges();
		$tracks = $rasp->challenges;

		// get list of challenge IDs with records in the database
		$query = 'SELECT DISTINCT challengeID FROM '.$ldb_settings['mysql']['prefix'].'records';
		$res = mysql_query($query);
		while ($row = mysql_fetch_row($res)) {
			$track = $row[0];
			// delete records & rs_times if it's not in server's challenge list
			if (!in_array($track, $tracks)) {
				$aseco->console_text('[RASP] ...challengeID: ' . $track);
				$query = 'DELETE FROM '.$ldb_settings['mysql']['prefix'].'records WHERE ChallengeID=' . $track;
				mysql_query($query);
				$query = 'DELETE FROM '.$ldb_settings['mysql']['prefix'].'rs_times WHERE challengeID=' . $track;
				mysql_query($query);
			}
		}
		mysql_free_result($res);
	}
}  // event_onstartup
?>
