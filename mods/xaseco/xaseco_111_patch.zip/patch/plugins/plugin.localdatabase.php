<?php
/* vim: set noexpandtab tabstop=2 softtabstop=2 shiftwidth=2: */

/**
 * This script saves record into a local database.
 * You can modify this file as you want, to advance
 * the information stored in the database!
 *
 * @author    Florian Schnell
 * @version   2.0
 * Updated by Xymph
 *
 * Dependencies: requires plugin.panels.php on TMF
 */

Aseco::registerEvent('onStartup', 'ldb_loadSettings');
Aseco::registerEvent('onStartup', 'ldb_connect');
Aseco::registerEvent('onEverySecond', 'ldb_reconnect');
Aseco::registerEvent('onSync', 'ldb_sync');
Aseco::registerEvent('onNewChallenge', 'ldb_newChallenge');
Aseco::registerEvent('onPlayerConnect', 'ldb_playerConnect');
Aseco::registerEvent('onPlayerDisconnect', 'ldb_playerDisconnect');
Aseco::registerEvent('onPlayerFinish', 'ldb_playerFinish');
Aseco::registerEvent('onPlayerWins', 'ldb_playerWins');
Aseco::registerEvent('onPlayerVote', 'ldb_vote');

// called @ onStartup
function ldb_loadSettings($aseco) {
	global $ldb_settings;

	$aseco->console_text('[Local DB] Load settings file [localdatabase.xml]');
	if (!$settings = $aseco->xml_parser->parseXml('localdatabase.xml')) {
		trigger_error('Could not read/parse Local database config file localdatabase.xml !', E_USER_ERROR);
	}
	$settings = $settings['SETTINGS'];

	// read mysql server settings
	$ldb_settings['mysql']['host'] = $settings['MYSQL_SERVER'][0];
	$ldb_settings['mysql']['login'] = $settings['MYSQL_LOGIN'][0];
	$ldb_settings['mysql']['password'] = $settings['MYSQL_PASSWORD'][0];
	$ldb_settings['mysql']['database'] = $settings['MYSQL_DATABASE'][0];
	$ldb_settings['mysql']['prefix'] = (empty($settings['MYSQL_PREFIX'][0]) ? '' : $settings['MYSQL_PREFIX'][0]);
	$ldb_settings['mysql']['connection'] = false;

	// display records in game?
	if (strtoupper($settings['DISPLAY'][0]) == 'TRUE')
		$ldb_settings['display'] = true;
	else
		$ldb_settings['display'] = false;

	// set highest record still to be displayed
	$ldb_settings['limit'] = $settings['LIMIT'][0];

	$ldb_settings['messages'] = $settings['MESSAGES'][0];
}  // ldb_loadSettings

// called @ onStartup
function ldb_connect($aseco) {
	global $maxrecs;

	// get the settings
	global $ldb_settings;
	// create data fields
	global $ldb_records;
	$ldb_records = new RecordList($maxrecs);
	global $ldb_challenge;
	$ldb_challenge = new Challenge();

	// log status message
	$aseco->console_text("[Local DB] Try to connect to MySQL server on '{1}' with database '{2}'",
	                     $ldb_settings['mysql']['host'], $ldb_settings['mysql']['database']);

	if (!$ldb_settings['mysql']['connection'] = mysql_connect($ldb_settings['mysql']['host'],
	                                                          $ldb_settings['mysql']['login'],
	                                                          $ldb_settings['mysql']['password'])) {
		trigger_error('[Local DB] Could not authenticate at MySQL server!', E_USER_ERROR);
	}

	if (!mysql_select_db($ldb_settings['mysql']['database'])) {
		trigger_error('[Local DB] Could not find MySQL database!', E_USER_ERROR);
	}

	// log status message
	$aseco->console_text('[Local DB] MySQL Server Version is ' . mysql_get_server_info());
	// optional UTF-8 handling fix
	//mysql_query('SET NAMES utf8');

	// add players 'TeamName' column if not yet done
	$result = mysql_query('SELECT TeamName FROM '.$ldb_settings['mysql']['prefix'].'players LIMIT 1');
	if (!$result) {
		if (mysql_errno() == 1054) {
			mysql_query("ALTER TABLE '.$ldb_settings['mysql']['prefix'].'players ADD TeamName char(60) NOT NULL default ''");
		}
	} else {
		mysql_free_result($result);
	}

	// enlarge challenges 'Name' column if not yet done
	$result = mysql_query('DESC '.$ldb_settings['mysql']['prefix'].'challenges Name');
	$row = mysql_fetch_row($result);
	mysql_free_result($result);
	if ($row[1] != 'varchar(100)') {
		mysql_query("ALTER TABLE '.$ldb_settings['mysql']['prefix'].'challenges MODIFY Name varchar(100) NOT NULL default ''");
	}

	// enlarge players 'NickName' column if not yet done
	$result = mysql_query('DESC '.$ldb_settings['mysql']['prefix'].'players NickName');
	$row = mysql_fetch_row($result);
	mysql_free_result($result);
	if ($row[1] != 'varchar(100)') {
		mysql_query("ALTER TABLE '.$ldb_settings['mysql']['prefix'].'players MODIFY NickName varchar(100) NOT NULL default ''");
	}

	// add 'Checkpoints' column if not yet done
	$fields = array();
	$result = mysql_query('SHOW COLUMNS FROM '.$ldb_settings['mysql']['prefix'].'records');
	while ($row = mysql_fetch_row($result))
		$fields[] = $row[0];
	mysql_free_result($result);
	if (!in_array('Checkpoints', $fields)) {
		mysql_query("ALTER TABLE '.$ldb_settings['mysql']['prefix'].'records ADD Checkpoints text NOT NULL");
	}

	// create table for extra players data
	$query = "CREATE TABLE IF NOT EXISTS `".$ldb_settings['mysql']['prefix']."players_extra` (
	            `playerID` mediumint(9) NOT NULL default 0,
	            `cps` smallint(3) NOT NULL default -1,
	            `dedicps` smallint(3) NOT NULL default -1,
	            `donations` mediumint(9) NOT NULL default 0,
	            `style` varchar(20) NOT NULL default '',
	            `panels` varchar(255) NOT NULL default '',
	            KEY `playerID` (`playerID`)
	          ) TYPE=MyISAM;";
	$result = mysql_query($query);

	if (!$result) {
		trigger_error('Could not create "players_extra" table! (' . mysql_error() . ')' . CRLF . 'sql = ' . $query, E_USER_WARNING);
	}
}  // ldb_connect

// called @ onEverySecond
function ldb_reconnect($aseco) {
	global $ldb_settings;

	// check if any players online
	if (empty($aseco->server->players->player_list)) {
		// check if MySQL connection still alive
		if (!mysql_ping($ldb_settings['mysql']['connection'])) {
			// connection timed out so reconnect
			mysql_close($ldb_settings['mysql']['connection']);
			if (!$ldb_settings['mysql']['connection'] = mysql_connect($ldb_settings['mysql']['host'],
			                                                          $ldb_settings['mysql']['login'],
			                                                          $ldb_settings['mysql']['password'])) {
				trigger_error('[Local DB] Could not authenticate at MySQL server!', E_USER_ERROR);
			}
			if (!mysql_select_db($ldb_settings['mysql']['database'])) {
				trigger_error('[Local DB] Could not find MySQL database!', E_USER_ERROR);
			}
			$aseco->console_text('[Local DB] Reconnected to MySQL Server');
		}
	}
}  // ldb_reconnect

// called @ onSync
function ldb_sync($aseco) {

/* ldb_playerConnect on sync already invoked via onPlayerConnect event,
   so disable it here - Xymph
	$aseco->console_text('[Local DB] Synchronize players with database');

	// take each player in the list and simulate a join
	while ($player = $aseco->server->players->nextPlayer()) {

		// log debug message
		if ($aseco->debug) $aseco->console_text('[Local DB] Sending player ' . $player->login);

		ldb_playerConnect($aseco, $player);
	}
disabled */

	// reset player list
	$aseco->server->players->resetPlayers();
}  // ldb_sync

// called @ onPlayerConnect
function ldb_playerConnect($aseco, $player) {
	global $ldb_settings;

	if ($aseco->server->getGame() == 'TMF')
		$nation = mapCountry($player->nation);
	else  // TMN/TMS/TMO
		$nation = $player->nation;

	// get player stats
	$query = 'SELECT wins, timeplayed, teamname
	          FROM '.$ldb_settings['mysql']['prefix'].'players
	          WHERE Login=' . quotedString($player->login); // .
	          // ' AND Game=' . quotedString($aseco->server->getGame());
	$result = mysql_query($query);

	if (mysql_num_rows($result) === false) {
		trigger_error('Could not get stats of connecting player! (' . mysql_error() . ')' . CRLF . 'sql = ' . $query, E_USER_WARNING);
	}

	// was retrieved
	if (mysql_num_rows($result) > 0) {
		$dbplayer = mysql_fetch_object($result);
		mysql_free_result($result);

		// update player stats
		if ($player->teamname == '' && $dbplayer->teamname != '') {
			$player->teamname = $dbplayer->teamname;
		}
		if ($player->wins < $dbplayer->wins) {
			$player->wins = $dbplayer->wins;
		}
		if ($player->timeplayed < $dbplayer->timeplayed) {
			$player->timeplayed = $dbplayer->timeplayed;
		}

		// update player data
		$query = 'UPDATE '.$ldb_settings['mysql']['prefix'].'players
		          SET NickName=' . quotedString($player->nickname) . ',
		              Nation=' . quotedString($nation) . ',
		              TeamName=' . quotedString($player->teamname) . ',
		              UpdatedAt=NOW()
		          WHERE Login=' . quotedString($player->login); // .
		          // ' AND Game=' . quotedString($aseco->server->getGame());
		$result = mysql_query($query);

		if (mysql_affected_rows() == -1) {
			trigger_error('Could not update connecting player! (' . mysql_error() . ')' . CRLF . 'sql = ' . $query, E_USER_WARNING);
		}

	// could not be retrieved
	} else {  // mysql_num_rows() == 0
		mysql_free_result($result);

		// insert player
		$query = 'INSERT INTO '.$ldb_settings['mysql']['prefix'].'players
		          (Login, Game, NickName, Nation, TeamName, UpdatedAt)
		          VALUES
		          (' . quotedString($player->login) . ', ' .
		           quotedString($aseco->server->getGame()) . ', ' .
		           quotedString($player->nickname) . ', ' .
		           quotedString($nation) . ', ' .
		           quotedString($player->teamname) . ', NOW())';

		$result = mysql_query($query);
		if (mysql_affected_rows() != 1) {
			trigger_error('Could not insert connecting player! (' . mysql_error() . ')' . CRLF . 'sql = ' . $query, E_USER_WARNING);
		}
	}

	$pid = $aseco->getPlayerId($player->login);
	// check for player's extra data
	$query = 'SELECT playerID
	          FROM '.$ldb_settings['mysql']['prefix'].'players_extra
	          WHERE playerID=' . $pid;
	$result = mysql_query($query);

	if (mysql_num_rows($result) === false) {
		trigger_error('Could not get player\'s extra data! (' . mysql_error() . ')' . CRLF . 'sql = ' . $query, E_USER_WARNING);
	}

	// was retrieved
	if (mysql_num_rows($result) > 0) {
		mysql_free_result($result);

	// could not be retrieved
	} else {  // mysql_num_rows() == 0
		mysql_free_result($result);

		// insert player's default extra data
		$query = 'INSERT INTO '.$ldb_settings['mysql']['prefix'].'players_extra
		          (playerID, cps, dedicps, donations, style, panels)
		          VALUES
		          (' . $pid . ', ' .
		           ($aseco->settings['auto_enable_cps'] ? 0 : -1) . ', ' .
		           ($aseco->settings['auto_enable_dedicps'] ? 0 : -1) . ', 0, ' .
		           quotedString($aseco->settings['window_style']) . ', ' .
		           quotedString($aseco->settings['admin_panel'] . '/' .
		                        $aseco->settings['donate_panel'] . '/' .
		                        $aseco->settings['records_panel'] . '/' .
		                        $aseco->settings['vote_panel']) . ')';
		$result = mysql_query($query);

		if (mysql_affected_rows() != 1) {
			trigger_error('Could not insert player\'s extra data! (' . mysql_error() . ')' . CRLF . 'sql = ' . $query, E_USER_WARNING);
		}
	}
}  // ldb_playerConnect

// called @ onPlayerDisconnect
function ldb_playerDisconnect($aseco, $player) {
	global $ldb_settings;

	// ignore fluke disconnects with empty logins
	if ($player->login == '') return;

	// update player
	$query = 'UPDATE '.$ldb_settings['mysql']['prefix'].'players
	          SET UpdatedAt=NOW(),
	              TimePlayed=TimePlayed+' . $player->getTimeOnline() . '
	          WHERE Login=' . quotedString($player->login); // .
	          // ' AND Game=' . quotedString($aseco->server->getGame());
	$result = mysql_query($query);

	if (mysql_affected_rows() == -1) {
		trigger_error('Could not update disconnecting player! (' . mysql_error() . ')' . CRLF . 'sql = ' . $query, E_USER_WARNING);
	}
}  // ldb_playerDisconnect

function ldb_getDonations($aseco, $login) {
	global $ldb_settings;

	// get player's donations
	$query = 'SELECT donations
	          FROM '.$ldb_settings['mysql']['prefix'].'players_extra
	          WHERE playerID=' . $aseco->getPlayerId($login);
	$result = mysql_query($query);

	if (mysql_num_rows($result) === false || mysql_num_rows($result) == 0) {
		mysql_free_result($result);
		trigger_error('Could not get player\'s donations! (' . mysql_error() . ')' . CRLF . 'sql = ' . $query, E_USER_WARNING);
		return false;
	} else {
		$dbextra = mysql_fetch_object($result);
		mysql_free_result($result);

		return $dbextra->donations;
	}
}  // ldb_getDonations

function ldb_updateDonations($aseco, $login, $donation) {
	global $ldb_settings;

	// update player's donations
	$query = 'UPDATE '.$ldb_settings['mysql']['prefix'].'players_extra
	          SET donations=donations+' . $donation . '
	          WHERE playerID=' . $aseco->getPlayerId($login);
	$result = mysql_query($query);

	if (mysql_affected_rows() != 1) {
		trigger_error('Could not update player\'s donations! (' . mysql_error() . ')' . CRLF . 'sql = ' . $query, E_USER_WARNING);
	}
}  // ldb_updateDonations

function ldb_getCPs($aseco, $login) {
	global $ldb_settings;

	// get player's CPs settings
	$query = 'SELECT cps, dedicps
	          FROM '.$ldb_settings['mysql']['prefix'].'players_extra
	          WHERE playerID=' . $aseco->getPlayerId($login);
	$result = mysql_query($query);

	if (mysql_num_rows($result) === false || mysql_num_rows($result) == 0) {
		mysql_free_result($result);
		trigger_error('Could not get player\'s CPs! (' . mysql_error() . ')' . CRLF . 'sql = ' . $query, E_USER_WARNING);
		return false;
	} else {
		$dbextra = mysql_fetch_object($result);
		mysql_free_result($result);

		return array('cps' => $dbextra->cps, 'dedicps' => $dbextra->dedicps);
	}
}  // ldb_getCPs

function ldb_setCPs($aseco, $login, $cps, $dedicps) {
	global $ldb_settings;

	$query = 'UPDATE '.$ldb_settings['mysql']['prefix'].'players_extra
	          SET cps=' . $cps . ', dedicps=' . $dedicps . '
	          WHERE playerID=' . $aseco->getPlayerId($login);
	$result = mysql_query($query);

	if (mysql_affected_rows() == -1) {
		trigger_error('Could not update player\'s CPs! (' . mysql_error() . ')' . CRLF . 'sql = ' . $query, E_USER_WARNING);
	}
}  // ldb_setCPs

function ldb_getStyle($aseco, $login) {
	global $ldb_settings;

	// get player's style
	$query = 'SELECT style
	          FROM '.$ldb_settings['mysql']['prefix'].'players_extra
	          WHERE playerID=' . $aseco->getPlayerId($login);
	$result = mysql_query($query);

	if (mysql_num_rows($result) === false || mysql_num_rows($result) == 0) {
		mysql_free_result($result);
		trigger_error('Could not get player\'s style! (' . mysql_error() . ')' . CRLF . 'sql = ' . $query, E_USER_WARNING);
		return false;
	} else {
		$dbextra = mysql_fetch_object($result);
		mysql_free_result($result);

		return $dbextra->style;
	}
}  // ldb_getStyle

function ldb_setStyle($aseco, $login, $style) {
	global $ldb_settings;

	$query = 'UPDATE '.$ldb_settings['mysql']['prefix'].'players_extra
	          SET style=' . quotedString($style) . '
	          WHERE playerID=' . $aseco->getPlayerId($login);
	$result = mysql_query($query);

	if (mysql_affected_rows() == -1) {
		trigger_error('Could not update player\'s style! (' . mysql_error() . ')' . CRLF . 'sql = ' . $query, E_USER_WARNING);
	}
}  // ldb_setStyle

function ldb_getPanels($aseco, $login) {
	global $ldb_settings;

	// get player's panels
	$query = 'SELECT panels
	          FROM '.$ldb_settings['mysql']['prefix'].'players_extra
	          WHERE playerID=' . $aseco->getPlayerId($login);
	$result = mysql_query($query);

	if (mysql_num_rows($result) === false || mysql_num_rows($result) == 0) {
		mysql_free_result($result);
		trigger_error('Could not get player\'s panels! (' . mysql_error() . ')' . CRLF . 'sql = ' . $query, E_USER_WARNING);
		return false;
	} else {
		$dbextra = mysql_fetch_object($result);
		mysql_free_result($result);

		$panel = explode('/', $dbextra->panels);
		$panels = array();
		$panels['admin'] = $panel[0];
		$panels['donate'] = $panel[1];
		$panels['records'] = $panel[2];
		$panels['vote'] = $panel[3];
		return $panels;
	}
}  // ldb_getPanels

function ldb_setPanel($aseco, $login, $type, $panel) {
	global $ldb_settings;

	// update player's panels
	$panels = ldb_getPanels($aseco, $login);
	$panels[$type] = $panel;
	$query = 'UPDATE '.$ldb_settings['mysql']['prefix'].'players_extra
	          SET panels=' . quotedString($panels['admin'] . '/' . $panels['donate'] . '/' .
	                                      $panels['records'] . '/' . $panels['vote']) . '
	          WHERE playerID=' . $aseco->getPlayerId($login);
	$result = mysql_query($query);

	if (mysql_affected_rows() == -1) {
		trigger_error('Could not update player\'s panels! (' . mysql_error() . ')' . CRLF . 'sql = ' . $query, E_USER_WARNING);
	}
}  // ldb_setPanel

// called @ onPlayerFinish
function ldb_playerFinish($aseco, $finish_item) {
	global $ldb_records, $ldb_settings,
	       $checkpoints;  // from plugin.checkpoints.php

	// if no actual finish, bail out immediately
	if ($finish_item->score == 0) return;

	// in Laps mode on real PlayerFinish event, bail out too
	if ($aseco->server->gameinfo->mode == 3 && !$finish_item->new) return;
	// reset lap "Finish" flag
	$finish_item->new = false;

	$login = $finish_item->player->login;
	$nickname = stripColors($finish_item->player->nickname);

	// drove a new record?
	// go through each of the XX records
	for ($i = 0; $i < $ldb_records->max; $i++) {
		$cur_record = $ldb_records->getRecord($i);

		// if player's time/score is better, or record isn't set (thanks eyez)
		if ($cur_record === false || ($aseco->server->gameinfo->mode == 4 ?
		                              $finish_item->score > $cur_record->score :
		                              $finish_item->score < $cur_record->score)) {

			// does player have a record already?
			$cur_rank = -1;
			$cur_score = 0;
			for ($rank = 0; $rank < $ldb_records->count(); $rank++) {
				$rec = $ldb_records->getRecord($rank);

				if ($rec->player->login == $login) {

					// new record worse than old one
					if ($aseco->server->gameinfo->mode == 4 ?
							$finish_item->score < $rec->score :
					    $finish_item->score > $rec->score) {
						return;

					// new record is better than or equal to old one
					} else {
						$cur_rank = $rank;
						$cur_score = $rec->score;
						break;
					}
				}
			}

			$finish_time = $finish_item->score;
			if ($aseco->server->gameinfo->mode != 4)
				$finish_time = formatTime($finish_time);

			if ($cur_rank != -1) {  // player has a record in topXX already

				// compute difference to old record
				if ($aseco->server->gameinfo->mode != 4) {
					$diff = $cur_score - $finish_item->score;
					$sec = floor($diff/1000);
					$hun = ($diff - ($sec * 1000)) / 10;
				} else {  // Stunts
					$diff = $finish_item->score - $cur_score;
				}

				// update record if improved
				if ($diff > 0) {
					$finish_item->new = true;
					$ldb_records->setRecord($cur_rank, $finish_item);
				}

				// player moved up in LR list
				if ($cur_rank > $i) {

					// move record to the new position
					$ldb_records->moveRecord($cur_rank, $i);

					// do a player improved his/her LR rank message
					$message = formatText($ldb_settings['messages']['RECORD_NEW_RANK'][0],
					                      $nickname,
					                      $i+1,
					                      ($aseco->server->gameinfo->mode == 4 ? 'Score' : 'Time'),
					                      $finish_time,
					                      $cur_rank+1,
					                      ($aseco->server->gameinfo->mode == 4 ?
					                       '+' . $diff : sprintf('-%d.%02d', $sec, $hun)));

					// show chat message to all or player
					if ($ldb_settings['display']) {
						if ($i < $ldb_settings['limit']) {
							if ($aseco->settings['recs_in_window'] && function_exists('send_window_message'))
								send_window_message($aseco, $message, false);
							else
								$aseco->client->query('ChatSendServerMessage', $aseco->formatColors($message));
						} else {
							$message = str_replace('{#server}>> ', '{#server}> ', $message);
							$aseco->client->query('ChatSendServerMessageToLogin', $aseco->formatColors($message), $login);
						}
					}

				} else {

					if ($diff == 0) {
						// do a player equaled his/her record message
						$message = formatText($ldb_settings['messages']['RECORD_EQUAL'][0],
						                      $nickname,
						                      $cur_rank+1,
						                      ($aseco->server->gameinfo->mode == 4 ? 'Score' : 'Time'),
						                      $finish_time);
					} else {
						// do a player secured his/her record message
						$message = formatText($ldb_settings['messages']['RECORD_NEW'][0],
						                      $nickname,
						                      $i+1,
						                      ($aseco->server->gameinfo->mode == 4 ? 'Score' : 'Time'),
						                      $finish_time,
						                      $cur_rank+1,
						                      ($aseco->server->gameinfo->mode == 4 ?
						                       '+' . $diff : sprintf('-%d.%02d', $sec, $hun)));
					}

					// show chat message to all or player
					if ($ldb_settings['display']) {
						if ($i < $ldb_settings['limit']) {
							if ($aseco->settings['recs_in_window'] && function_exists('send_window_message'))
								send_window_message($aseco, $message, false);
							else
								$aseco->client->query('ChatSendServerMessage', $aseco->formatColors($message));
						} else {
							$message = str_replace('{#server}>> ', '{#server}> ', $message);
							$aseco->client->query('ChatSendServerMessageToLogin', $aseco->formatColors($message), $login);
						}
					}
				}

			} else {  // player hasn't got a record yet

				// if previously tracking own/last local record, now track new one
				if (isset($checkpoints[$login]) &&
				    $checkpoints[$login]->loclrec == 0 && $checkpoints[$login]->dedirec == -1) {
					$checkpoints[$login]->best_fin = $checkpoints[$login]->curr_fin;
					$checkpoints[$login]->best_cps = $checkpoints[$login]->curr_cps;
				}

				// insert new record at the specified position
				$finish_item->new = true;
				$ldb_records->addRecord($finish_item, $i);

				// do a player drove first record message
				$message = formatText($ldb_settings['messages']['RECORD_FIRST'][0],
				                      $nickname,
				                      $i+1,
				                      ($aseco->server->gameinfo->mode == 4 ? 'Score' : 'Time'),
				                      $finish_time);

				// show chat message to all or player
				if ($ldb_settings['display']) {
					if ($i < $ldb_settings['limit']) {
						if ($aseco->settings['recs_in_window'] && function_exists('send_window_message'))
							send_window_message($aseco, $message, false);
						else
							$aseco->client->query('ChatSendServerMessage', $aseco->formatColors($message));
					} else {
						$message = str_replace('{#server}>> ', '{#server}> ', $message);
						$aseco->client->query('ChatSendServerMessageToLogin', $aseco->formatColors($message), $login);
					}
				}
			}

			// update aseco records
			$aseco->server->records = $ldb_records;

			// log records when debugging is set to true
			//if ($aseco->debug) $aseco->console_text('ldb_playerFinish records:' . CRLF . print_r($ldb_records, true));

			// insert and log a new local record (not an equalled one)
			if ($finish_item->new) {
				ldb_insert_record($finish_item, isset($checkpoints[$login]) ?
				                  implode(',', $checkpoints[$login]->curr_cps) : '');

				// update all panels if new #1 record
				if ($aseco->server->getGame() == 'TMF' && $i == 0) {
					setRecordsPanel('local', ($aseco->server->gameinfo->mode == 4 ?
					                          str_pad($finish_item->score, 5, ' ', STR_PAD_LEFT) :
					                          formatTime($finish_item->score)));
					if (function_exists('update_allrecpanels'))
						update_allrecpanels($aseco, null);  // from plugin.panels.php
				}

				// log record message in console
				$aseco->console('[Local DB] player {1} finished with {2} and took the {3}. LR place!',
				                $login, $finish_item->score, $i+1);
			}

			// release a "local record" event
			$aseco->releaseEvent('onLocalRecord', $finish_item);

			// got the record, now stop!
			return;
		}
	}
}  // ldb_playerFinish

function ldb_insert_record($record, $cps) {
	global $aseco, $ldb_challenge, $ldb_settings;

	if (!$playerid = $aseco->getPlayerId($record->player->login)) {
		trigger_error('Player [' . $record->player->login . '] was not found in the database!', E_USER_WARNING);
		return;
	}

	// insert new record
	$query = 'INSERT INTO '.$ldb_settings['mysql']['prefix'].'records
	          (ChallengeId, PlayerId, Score, Date, Checkpoints)
	          VALUES
	          (' . $ldb_challenge->id . ', ' . $playerid . ', ' .
	           $record->score . ', NOW(), ' . quotedString($cps) . ')';
	$result = mysql_query($query);

	if (mysql_affected_rows() == -1) {
		$error = mysql_error();
		if (!preg_match('/Duplicate entry.*for key/', $error))
			trigger_error('Could not insert record! (' . $error . ')' . CRLF . 'sql = ' . $query, E_USER_WARNING);
	}

	// could not be inserted?
	if (mysql_affected_rows() != 1) {
		// update existing record
		$query = 'UPDATE '.$ldb_settings['mysql']['prefix'].'records
		          SET Score=' . $record->score . ', Date=NOW(), Checkpoints=' . quotedString($cps) . '
		          WHERE ChallengeId=' . $ldb_challenge->id . ' AND PlayerId=' . $playerid;
		$result = mysql_query($query);

		// could not be updated?
		if (mysql_affected_rows() != 1) {
			trigger_error('Could not update record! (' . mysql_error() . ')' . CRLF . 'sql = ' . $query, E_USER_WARNING);
		}
	}
}  // ldb_insert_record

function ldb_removeRecord($aseco, $cid, $pid, $recno) {
	global $ldb_records, $ldb_settings;

	// remove record
	$query = 'DELETE FROM '.$ldb_settings['mysql']['prefix'].'records WHERE ChallengeId=' . $cid . ' AND PlayerId=' . $pid;
	$result = mysql_query($query);
	if (mysql_affected_rows() != 1) {
		trigger_error('Could not remove record! (' . mysql_error() . ')' . CRLF . 'sql = ' . $query, E_USER_WARNING);
	}

	// remove record from specified position
	$ldb_records->delRecord($recno);

	// check if fill up is needed
	if ($ldb_records->count() == ($ldb_records->max - 1)) {
		// get max'th time
		$query = 'SELECT DISTINCT playerid,score FROM '.$ldb_settings['mysql']['prefix'].'rs_times t1 WHERE challengeid=' . $cid .
		         ' AND score=(SELECT MIN(t2.score) FROM '.$ldb_settings['mysql']['prefix'].'rs_times t2 WHERE challengeid=' . $cid .
		         '            AND t1.playerid=t2.playerid) ORDER BY score,date LIMIT ' . ($ldb_records->max - 1) . ',1';
		$result = mysql_query($query);
		if (mysql_num_rows($result) == 1) {
			$timerow = mysql_fetch_object($result);

			// get corresponding date/time & checkpoints
			$query = 'SELECT date,checkpoints FROM '.$ldb_settings['mysql']['prefix'].'rs_times WHERE challengeid=' . $cid .
			         ' AND playerid=' . $timerow->playerid . ' ORDER BY score,date LIMIT 1';
			$result2 = mysql_query($query);
			$timerow2 = mysql_fetch_object($result2);
			$datetime = date('Y-m-d H:i:s', $timerow2->date);
			mysql_free_result($result2);

			// insert new max'th record
			$query = "INSERT INTO '.$ldb_settings['mysql']['prefix'].'records
			          (ChallengeId, PlayerId, Score, Date, Checkpoints)
			          VALUES
			          (" . $cid . ", " . $timerow->playerid . ", " .
			           $timerow->score . ", '" . $datetime . "', '" .
			           $timerow2->checkpoints . "')";
			$result2 = mysql_query($query);

			// couldn't be inserted? then player had a record already
			if (mysql_affected_rows() != 1) {
				// update max'th record just to be sure it's correct
				$query = "UPDATE '.$ldb_settings['mysql']['prefix'].'records
				          SET Score=" . $timerow->score . ", Checkpoints='" . $timerow2->checkpoints . "', Date='" . $datetime . "'
				          WHERE ChallengeId=" . $cid . " AND PlayerId=" . $timerow->playerid;
				$result2 = mysql_query($query);
			} 

			// get player info
			$query = 'SELECT * FROM '.$ldb_settings['mysql']['prefix'].'players WHERE id=' . $timerow->playerid;
			$result2 = mysql_query($query);
			$playrow = mysql_fetch_array($result2);
			mysql_free_result($result2);

			// create record object
			$record_item = new Record();
			$record_item->score = $timerow->score;
			$record_item->checks = ($timerow2->checkpoints != '' ? explode(',', $timerow2->checkpoints) : array());
			$record_item->new = false;

			// create a player object to put it into the record object
			$player_item = new Player();
			$player_item->nickname = $playrow['NickName'];
			$player_item->login = $playrow['Login'];
			$record_item->player = $player_item;

			// add the track information to the record object
			$record_item->challenge = clone $aseco->server->challenge;
			unset($record_item->challenge->gbx);  // reduce memory usage
			unset($record_item->challenge->tmx);

			// add the created record to the list
			$ldb_records->addRecord($record_item);
		}
		mysql_free_result($result);
	}

	// update aseco records
	$aseco->server->records = $ldb_records;
}  // ldb_remove_record

// called @ onNewChallenge
function ldb_newChallenge($aseco, $challenge) {
	global $ldb_challenge, $ldb_records, $ldb_settings;

	$ldb_records->clear();

	$order = ($aseco->server->gameinfo->mode == 4 ? 'DESC' : 'ASC');
	$query = 'SELECT c.Id AS ChallengeId, r.Score, p.NickName, p.Login, r.Date, r.Checkpoints,
	                 SUM(v.Score) AS VotingSum, COUNT(v.Score) AS VotingCount
	          FROM '.$ldb_settings['mysql']['prefix'].'challenges c
	          LEFT JOIN '.$ldb_settings['mysql']['prefix'].'records r ON (r.ChallengeId=c.Id)
	          LEFT JOIN '.$ldb_settings['mysql']['prefix'].'votes v ON (v.ChallengeId=c.Id)
	          LEFT JOIN '.$ldb_settings['mysql']['prefix'].'players p ON (r.PlayerId=p.Id)
	          WHERE c.Uid=' . quotedString($challenge->uid) . '
	          GROUP BY r.Id
	          ORDER BY r.Score ' . $order . ',r.Date ASC
	          LIMIT ' . $ldb_records->max;
	$result = mysql_query($query);

	if (mysql_num_rows($result) === false) {
		trigger_error('Could not get challenge info! (' . mysql_error() . ')' . CRLF . 'sql = ' . $query, E_USER_WARNING);
	}

	// challenge found?
	if (mysql_num_rows($result) > 0) {

		// get each record
		while ($record = mysql_fetch_array($result)) {

			// create record object
			$record_item = new Record();
			$record_item->score = $record['Score'];
			$record_item->checks = ($record['Checkpoints'] != '' ? explode(',', $record['Checkpoints']) : array());
			$record_item->new = false;

			// create a player object to put it into the record object
			$player_item = new Player();
			$player_item->nickname = $record['NickName'];
			$player_item->login = $record['Login'];
			$record_item->player = $player_item;

			// add the track information to the record object
			$record_item->challenge = clone $challenge;
			unset($record_item->challenge->gbx);  // reduce memory usage
			unset($record_item->challenge->tmx);

			// add the created record to the list
			$ldb_records->addRecord($record_item);

			$ldb_challenge->id = $record['ChallengeId'];
			$ldb_challenge->score = $record['VotingSum'];
			$ldb_challenge->votes = $record['VotingCount'];

			$challenge->id = $record['ChallengeId'];  // was inside the following if statement block

			// get challenge info
			if ($ldb_settings['display']) {
				$challenge->score = $record['VotingSum'];
				$challenge->votes = $record['VotingCount'];
			}
		}

		// update aseco records
		$aseco->server->records = $ldb_records;

		// log records when debugging is set to true
		//if ($aseco->debug) $aseco->console_text('ldb_newChallenge records:' . CRLF . print_r($ldb_records, true));

		mysql_free_result($result);

	// challenge isn't in database yet
	} else {

		// then create it
		$query = 'INSERT INTO '.$ldb_settings['mysql']['prefix'].'challenges
		          (Uid, Name, Author, Environment)
		          VALUES
		          (' . quotedString($challenge->uid) . ', ' .
		           quotedString(stripColors($challenge->name)) . ', ' .
		           quotedString($challenge->author) . ', ' .
		           quotedString($challenge->environment) . ')';
		$result = mysql_query($query);

		// challenge was inserted successfully
		if (mysql_affected_rows() == 1) {

			// get its Id now
			$query = 'SELECT Id FROM '.$ldb_settings['mysql']['prefix'].'challenges
			          WHERE Uid=' . quotedString($challenge->uid);
			$result = mysql_query($query);

			if (mysql_num_rows($result) == 1) {

				$row = mysql_fetch_row($result);
				$ldb_challenge->id = $row[0];
				$challenge->id = $row[0];  // added this so it could have the id for karma stuff (and maybe other things)
				$aseco->server->records->clear();

			} else {
				// challenge Id could not be found
				trigger_error('Could not get new challenge id! (' . mysql_error() . ')' . CRLF . 'sql = ' . $query, E_USER_WARNING);
			}
			mysql_free_result($result);

		} else {
			trigger_error('Could not insert new challenge! (' . mysql_error() . ')' . CRLF . 'sql = ' . $query, E_USER_WARNING);
		}
	}
}  // ldb_newChallenge

// called @ onPlayerWins
function ldb_playerWins($aseco, $player) {
	global $ldb_settings;

	$wins = $player->getWins();
	$query = 'UPDATE '.$ldb_settings['mysql']['prefix'].'players
	          SET Wins=' . $wins . '
	          WHERE Login=' . quotedString($player->login);
	$result = mysql_query($query);

	if (mysql_affected_rows() != 1) {
		trigger_error('Could not update winning player! (' . mysql_error() . ')' . CRLF . 'sql = ' . $query, E_USER_WARNING);
	}
}  // ldb_playerWins

// called @ onPlayerVote
function ldb_vote($aseco, $vote) {
	global $ldb_settings;

	$score = $vote['params'];
	$player = $vote['author'];

	if (!$playerid = $aseco->getPlayerId($player->login)) {
		trigger_error('Player [' . $player->login . '] was not found in the database!', E_USER_WARNING);
		return;
	}

	// insert vote
	$query = 'INSERT INTO '.$ldb_settings['mysql']['prefix'].'votes
	          (Score, PlayerId, ChallengeId)
	          VALUES
	          (' . $score . ', ' . $playerid . ', ' . $aseco->server->challenge->id . ')';
	$result = mysql_query($query);

	if (mysql_affected_rows() != 1) {
		if (!preg_match('/Duplicate entry.*for key/', $error))
			trigger_error('Could not insert vote! (' . mysql_error() . ')' . CRLF . 'sql = ' . $query, E_USER_WARNING);
	}
}  // ldb_vote
?>
