<?php
// Geh aB Clan 2009 - www.gab-clan.org
// $Id$

$axx_file['center']		= 2;
$axx_file['viewown']	= 2;
$axx_file['view']			= 2;
$axx_file['create']   = 2;

$axx_file['manage']   = 4;
$axx_file['options']  = 5;
$axx_file['viewsite']	= 1;
