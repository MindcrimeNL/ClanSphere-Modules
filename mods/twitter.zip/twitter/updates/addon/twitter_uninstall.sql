DROP TABLE `{pre}_twitter`;

DELETE FROM {pre}_options WHERE options_mod = 'twitter';
