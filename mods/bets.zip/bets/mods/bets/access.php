<?php
// Modul Name :     Bets
// CS Version :     Clansphere 2009

####################################################################################################

// users
$axx_file['com_create']  = 2;
$axx_file['com_edit']   = 2;
$axx_file['com_remove'] = 5;
$axx_file['center']  = 2;
$axx_file['place_bet']  = 2;
$axx_file['remove_placed_bet']  = 2;

// admins
$axx_file['manage']		= 4;
$axx_file['create']		= 4;
$axx_file['edit']		= 4;
$axx_file['result']		= 4;

// webmaster
$axx_file['remove']		= 5;
$axx_file['options']	= 5;

// general
$axx_file['list']		= 0;
$axx_file['view']  = 0;
$axx_file['toplist']		= 0;
$axx_file['navlist']  = 0;
?>
