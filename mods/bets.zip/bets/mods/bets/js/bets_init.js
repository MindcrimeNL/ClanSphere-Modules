/* init the quote type */
var selectObject = document.getElementById('bets_quote_type');
cs_bet_toggle_quote(selectObject);