<?php
// Clansphere 2009
// ticker - access.php - flow
// 2007-08-13
// based on the Tickermodule from Mr.AndersoN

$axx_file['create']	= 4;
$axx_file['edit']	= 4;
$axx_file['manage']	= 4;
$axx_file['remove']	= 5;

$axx_file['options'] = 5;

$axx_file['display'] = 1;

?>