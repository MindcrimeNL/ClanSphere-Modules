<?php
// ClanSphere 2010 - www.clansphere.net
// $Id$

$axx_file['create']  = 4;
$axx_file['manage'] = 4;
$axx_file['edit'] = 4;
$axx_file['remove']  = 4;
$axx_file['start'] = 4;
$axx_file['restart'] = 4;
$axx_file['teams'] = 4;
$axx_file['teamremove'] = 4;
$axx_file['teamadd'] = 4;
$axx_file['teamcheckin'] = 4;
$axx_file['seed'] = 4;
$axx_file['options'] = 5;

$axx_file['view'] = 1;
$axx_file['list'] = 1;
$axx_file['match'] = 1;
$axx_file['matchlist'] = 1;
$axx_file['tree'] = 1;
$axx_file['halloffame'] = 1;
$axx_file['result'] = 1;

$axx_file['center'] = 2;
$axx_file['matchedit'] = 2;
$axx_file['join'] = 2;
$axx_file['checkin'] = 2;

$axx_file['com_create'] = 1;
$axx_file['com_edit'] = 2;
$axx_file['com_remove'] = 2;

$axx_file['viewtree'] = 1;
$axx_file['viewtree_losers'] = 1;
$axx_file['viewtree_extra'] = 1;
