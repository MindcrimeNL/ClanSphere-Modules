<?php
// Geh aB Clan 2010 - www.gab-clan.org
// $Id$

// German

$cs_lang['mod_name']  = 'Konvert';
$cs_lang['modtext']  = 'XXX zu ClanSphere konvertieren';

// manage
$cs_lang['fake']  = 'Test Konversion';
$cs_lang['url'] = 'URL Webspell';
$cs_lang['user']  = 'DB Benutzer';
$cs_lang['pass']  = 'DB Passwort';
$cs_lang['name']  = 'DB Name';
$cs_lang['prefix']  = 'DB Prefix';
$cs_lang['charset']  = 'DB Zeichensatz (ISO-8859-1, UTF-8)';
$cs_lang['host']  = 'DB Host';
$cs_lang['port']  = 'DB Port';
$cs_lang['type']  = 'DB Type';
$cs_lang['conversion_errors'] = 'Konvertierungs fehler';
$cs_lang['statistics'] = 'Konvertierungs  statistik';

$cs_lang['convert']  = 'Konvertieren';

$cs_lang['users']  = 'Benutzer';
$cs_lang['squads']  = 'Teams';
$cs_lang['members']  = 'Mitglieder';
$cs_lang['wars']  = 'Clanwars';
$cs_lang['games']  = 'Spiele';
$cs_lang['clans']  = 'Clans';
$cs_lang['news']  = 'News';
$cs_lang['board']  = 'Forums';
$cs_lang['threads']  = 'Forum Themen';
$cs_lang['categories']  = 'Kategorien';

$cs_lang['preferred_language'] = 'Bevorzugte Konvertierte Sprache';
$cs_lang['convert_members']  = 'Konvertiere Mitglieder und Teams';
$cs_lang['convert_wars']  = 'Konvertiere Clanwars und Spiele';
$cs_lang['convert_news']  = 'Konvertiere News';
$cs_lang['convert_board']  = 'Konvertiere Forums';
$cs_lang['wars_needs_members']  = 'Clanwars k&ouml;nnen ohne Mitglieder und Team nicht konvertiert werden';
$cs_lang['wars_needs_category']  = 'Clanwars k&ouml;nnen ohne Kategorie nicht konvertiert werden';
$cs_lang['games_needs_category']  = 'Spiele k&ouml;nnen ohne Kategorie nicht konvertiert werden';
$cs_lang['mbstring_required']  = 'Die PHP mbstring Bibliothek ist erfordert';

