ALTER TABLE `{pre}_access` DROP `access_convert`;
