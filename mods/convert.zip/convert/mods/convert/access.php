<?php
// Geh aB Clan 2010 - www.gab-clan.org
// $Id$

$axx_file['manage']   = 5;
