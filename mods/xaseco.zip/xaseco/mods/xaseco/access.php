<?php

$axx_file['view_challenge']	= 0;
$axx_file['view_player']	= 0;
$axx_file['navlist']	= 0;
$axx_file['list_challenges'] = 0;
$axx_file['list'] = 0;
$axx_file['options'] = 5;

?>
