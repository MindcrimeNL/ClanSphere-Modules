<?php

/* xaseco: German language */
$cs_lang['mod_name']    = 'TMN XAseco';
$cs_lang['mod_text']    = 'TMN XAseco';
$cs_lang['mod'] 				=	'TMN XAseco';

$cs_lang['list']				=	'List';
$cs_lang['challenges']	=	'Strecken';
$cs_lang['players']			=	'Spieler';

$cs_lang['wins']				= 'Siege';
$cs_lang['time_played']	= 'Gespielt';
$cs_lang['days']				= 'Tag(e)';

$cs_lang['rank']				= 'Nr.';
$cs_lang['score']				= 'Zeit';
$cs_lang['challenge']		=	'Strecke';
$cs_lang['name']				= 'Name';
$cs_lang['author']			= 'Author';
$cs_lang['environment']	= 'Umgebung';

$cs_lang['no_challenge'] = 'Unbekante Strecke!';
$cs_lang['no_player'] = 'Unbekanter Spieler!';
$cs_lang['no_challenges'] = 'Keine Strecken vorhanden!';
$cs_lang['no_records'] = 'Keine Zeiten vorhanden!';

$cs_lang['bgcolor'] = 'Webseite Hintergrundfarbe (f&uuml;r automatischer Kontrast)';
?>
