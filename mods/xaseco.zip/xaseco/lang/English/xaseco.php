<?php

/* xaseco: English language */
$cs_lang['mod_name']    = 'TMN XAseco';
$cs_lang['mod_text']    = 'TMN XAseco';
$cs_lang['mod'] 				=	'TMN XAseco';

$cs_lang['list']				=	'List';
$cs_lang['challenges']	=	'Challenges';
$cs_lang['players']			=	'Players';

$cs_lang['wins']				= 'Wins';
$cs_lang['time_played']				= 'Time Played';
$cs_lang['days']				= 'day(s)';

$cs_lang['rank']				= 'Nr.';
$cs_lang['score']				= 'Time';
$cs_lang['challenge']		=	'Challenge';
$cs_lang['name']				= 'Name';
$cs_lang['author']			= 'Author';
$cs_lang['environment']	= 'Environment';

$cs_lang['no_challenge'] = 'Unknown challenge!';
$cs_lang['no_player'] = 'Unknown player!';
$cs_lang['no_challenges'] = 'No challenges available!';
$cs_lang['no_records'] = 'No records available!';

$cs_lang['bgcolor'] = 'Website background color (for auto contrast)';
?>
