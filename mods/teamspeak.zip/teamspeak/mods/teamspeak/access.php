<?php
// Clansphere 2009
// $Id: access.php,v 1.3 2006/05/06 20:28:21 hajo Exp $

$axx_file['view']	= 1;
$axx_file['list'] = 1;
$axx_file['center']	= 2;
$axx_file['create_uaccount']	= 2;
$axx_file['delete_uaccount']	= 2;
$axx_file['navlistcount'] = 1;
$axx_file['manage'] = 4;
$axx_file['serveradd'] = 4;
$axx_file['serveredit'] = 4;
$axx_file['serverlist'] = 4;
$axx_file['serverdel'] = 4;
$axx_file['userdblist'] = 4;
$axx_file['userkick'] = 4;
$axx_file['userchannelkick'] = 4;
$axx_file['navlist_tree'] = 1;
$axx_file['navlist_1'] = 1;
$axx_file['options'] = 5;

?>
