DROP TABLE `{pre}_datacache`;

DELETE FROM {pre}_options WHERE options_mod = 'datacache';
