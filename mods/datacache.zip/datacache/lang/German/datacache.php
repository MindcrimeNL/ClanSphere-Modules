<?php
// Geh aB Clan 2009 - www.gab-clan.org
// $Id$

// German

$cs_lang['mod_name']  = 'Data Cache';
$cs_lang['modtext']  = 'Caching von generierten Daten';

// manage
$cs_lang['mod']  = 'Modul';
$cs_lang['action']  = 'Aktion';
$cs_lang['key']  = 'Schl&uuml;ssel';
$cs_lang['time']  = 'Zeit';
$cs_lang['timeout_short']  = 'Akt. nach (Sek.)';
$cs_lang['timeout']  = 'Aktualisieren nach (Sek.)';
$cs_lang['showall'] = 'Alle anzeigen';
$cs_lang['view'] = 'Inhalt ansehen';

// remove
$cs_lang['remove_rly']       = 'Datensatz Nr. %s wirklich entfernen?';
$cs_lang['del_false']                    = 'Datacache l&ouml;schen abgebrochen';
$cs_lang['del_true']                     = 'Datacache l&ouml;schen erfolgreich';

// view
$cs_lang['expires'] = 'Verstreicht';
$cs_lang['never'] = 'Niemals';
$cs_lang['data'] = 'Daten';
$cs_lang['raw_data'] = 'Rohe Daten';
