<?php
// Geh aB Clan 2009 - www.gab-clan.org
// $Id$

// English

$cs_lang['mod_name']  = 'Data Cache';
$cs_lang['modtext']  = 'Caching of generated data';

// manage
$cs_lang['mod']  = 'Module';
$cs_lang['action']  = 'Action';
$cs_lang['key']  = 'Key';
$cs_lang['time']  = 'Time';
$cs_lang['timeout_short']  = 'Refresh (secs)';
$cs_lang['timeout']  = 'Refresh time (secs)';
$cs_lang['showall'] = 'Show all';
$cs_lang['view'] = 'View content';

// remove
$cs_lang['remove_rly']       = 'Really delete dataset no. %s ?';
$cs_lang['del_false']                    = 'Datacache deletion aborted';
$cs_lang['del_true']                     = 'Datacache deletion successful';

// view
$cs_lang['expires'] = 'Expires';
$cs_lang['never'] = 'Never';
$cs_lang['data'] = 'Data';
$cs_lang['raw_data'] = 'Raw data';
