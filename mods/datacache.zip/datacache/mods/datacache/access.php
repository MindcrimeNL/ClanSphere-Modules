<?php
// Geh aB Clan 2009 - www.gab-clan.org
// $Id$

$axx_file['manage']   = 5;
$axx_file['options']  = 5;
$axx_file['remove']   = 5;
$axx_file['view']			= 5;