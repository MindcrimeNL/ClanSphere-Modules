<?php
// Modul Name :     Coins
// CS Version :     Clansphere 2009

####################################################################################################

// users
$axx_file['center']  = 2;

// admins
$axx_file['manage']		= 4;
$axx_file['create']		= 4;
$axx_file['edit']		= 4;

// webmaster
$axx_file['remove']		= 5;
$axx_file['options']	= 5;

?>
