ALTER TABLE {pre}_servers ADD servers_rcon varchar(80) NOT NULL default '' AFTER servers_query;

