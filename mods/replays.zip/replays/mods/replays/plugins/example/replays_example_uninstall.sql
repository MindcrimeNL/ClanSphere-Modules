DROP TABLE `{pre}_replays_example`;

DELETE FROM {pre}_options WHERE options_mod = 'replays_example';