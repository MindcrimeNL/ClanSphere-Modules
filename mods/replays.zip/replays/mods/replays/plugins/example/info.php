<?php
// Geh aB Clan 2011 - www.gab-clan.org
// $Id$

$plugin_info['name']    = 'Example Replays plugin';
$plugin_info['version']  = $cs_main['version_name'];
$plugin_info['released']  = $cs_main['version_date'];
$plugin_info['creator']  = 'Mindcrime';
$plugin_info['team']    = 'GaB e.V.';
$plugin_info['url']    = 'www.gab-clan.org';
$plugin_info['text']    = 'This is just an example plugin';
$plugin_info['icon']    = 'cam_unmount';
$plugin_info['show']    = array('clansphere/admin' => 3, 'options/roots' => 5);
$plugin_info['categories']  = FALSE;
$plugin_info['comments']  = FALSE;
$plugin_info['protected']  = FALSE;
$plugin_info['tables']    = array('replays_example');
