<?php
// ClanSphere 2010 - www.clansphere.net
// $Id: access.php 4120 2010-06-15 15:29:39Z hajo $

$axx_file['create']    = 3;
$axx_file['edit']    = 3;
$axx_file['list']    = 1;
$axx_file['view']    = 1;
$axx_file['manage']    = 3;
$axx_file['remove']    = 4;
$axx_file['options']  = 5;

$axx_file['com_create']  = 1;
$axx_file['com_edit']  = 2;
$axx_file['com_remove']  = 5;
