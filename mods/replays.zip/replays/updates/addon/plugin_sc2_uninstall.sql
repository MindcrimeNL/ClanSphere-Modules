DROP TABLE `{pre}_replays_sc2`;

DELETE FROM {pre}_options WHERE options_mod = 'replays_sc2';
