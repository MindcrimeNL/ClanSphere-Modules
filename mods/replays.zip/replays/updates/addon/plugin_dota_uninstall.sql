DROP TABLE `{pre}_replays_dota`;

DELETE FROM {pre}_options WHERE options_mod = 'replays_dota';
