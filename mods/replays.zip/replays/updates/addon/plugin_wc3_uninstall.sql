DROP TABLE `{pre}_replays_wc3`;

DELETE FROM {pre}_options WHERE options_mod = 'replays_wc3';